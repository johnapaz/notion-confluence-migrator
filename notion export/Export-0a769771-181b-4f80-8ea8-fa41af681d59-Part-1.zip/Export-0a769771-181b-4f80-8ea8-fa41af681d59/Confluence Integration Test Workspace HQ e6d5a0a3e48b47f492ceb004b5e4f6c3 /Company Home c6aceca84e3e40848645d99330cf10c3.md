# Company Home

Convert all those scattered pages into a Notion database with one click — while keeping the easy-to-read page format.

<aside>
💡 **Notion Tip:** Use this template to organize important information for your team. Add owners, verification, and tags to pages to keep them up to date. Just replace this sample content with your own.

</aside>

---

## Team

---

[Getting Started](Company%20Home%20c6aceca84e3e40848645d99330cf10c3/Getting%20Started%203922810d114548ef916d934452c9e506.md)

[Mission, Vision, Values](Company%20Home%20c6aceca84e3e40848645d99330cf10c3/Mission,%20Vision,%20Values%208f33e9cc5e674165bd501c7e5a007417.md)

[Global Offices](Company%20Home%20c6aceca84e3e40848645d99330cf10c3/Global%20Offices%2024bc479486cd4843b9d54dc420cd8939.csv)

[Corporate Travel](Company%20Home%20c6aceca84e3e40848645d99330cf10c3/Corporate%20Travel%20bb7d0c7655a34decaec3525ba67327b4.md)

[Recent Press](Company%20Home%20c6aceca84e3e40848645d99330cf10c3/Recent%20Press%20ed8f88a4950a4ff284fdcea21085260e.md)

[What’s New?](Company%20Home%20c6aceca84e3e40848645d99330cf10c3/What%E2%80%99s%20New%209af8bd64eca345e28257fdcade466e62.md)

## Policies

---

[Vacation Policy](Company%20Home%20c6aceca84e3e40848645d99330cf10c3/Vacation%20Policy%2050c919abf3484bfc8b6e6c4b2ce3a084.md)

[ Morale Events](Company%20Home%20c6aceca84e3e40848645d99330cf10c3/Morale%20Events%2029663dc81155491cad0f6fa776ff8104.md)

[Benefits Policies](Company%20Home%20c6aceca84e3e40848645d99330cf10c3/Benefits%20Policies%20c2d8dbf6072e4406a7059aa5a5b8e694.md)

[Expense Policy](Company%20Home%20c6aceca84e3e40848645d99330cf10c3/Expense%20Policy%20d24daf79b7a54754ae96cfd54c937e7d.md)

[Untitled Database](Company%20Home%20c6aceca84e3e40848645d99330cf10c3/Untitled%20Database%20fedb7bbfd5dd4b54b0e67708e3516185.csv)

[Global Offices](Company%20Home%20c6aceca84e3e40848645d99330cf10c3/Global%20Offices%20a6508a8fdac74a868f448100ae195a5d.csv)