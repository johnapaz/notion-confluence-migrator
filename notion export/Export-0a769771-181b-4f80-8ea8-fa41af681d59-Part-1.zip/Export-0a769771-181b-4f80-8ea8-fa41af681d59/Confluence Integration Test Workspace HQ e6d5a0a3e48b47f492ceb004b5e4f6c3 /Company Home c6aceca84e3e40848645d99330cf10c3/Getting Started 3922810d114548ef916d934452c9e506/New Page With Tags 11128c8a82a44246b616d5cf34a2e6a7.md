# New Page With Tags

Owner: John
Tags: Company Updates, Policies
Last edited time: July 29, 2024 10:24 PM
Created time: July 29, 2024 10:24 PM

<aside>
💡 Notion Tip: Tag pages to let collaborators know what they can expect to use the page for. You can add one or many tags to any page in a wiki.

</aside>