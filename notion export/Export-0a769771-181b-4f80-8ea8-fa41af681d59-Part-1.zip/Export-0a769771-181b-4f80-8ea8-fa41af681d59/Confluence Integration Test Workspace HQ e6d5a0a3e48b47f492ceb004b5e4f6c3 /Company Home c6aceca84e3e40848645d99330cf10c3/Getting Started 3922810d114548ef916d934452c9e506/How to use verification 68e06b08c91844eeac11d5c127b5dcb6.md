# How to use verification

Owner: John
Verification: Verified
Last edited time: July 29, 2024 10:24 PM
Created time: July 29, 2024 10:24 PM

<aside>
💡 Notion Tip: An owner of a page can verify it by clicking on the verification button above and choosing to verify the page for either a set amount of time or indefinitely!

</aside>