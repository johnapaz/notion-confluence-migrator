# Mission, Vision, Values

Owner: John
Tags: Company Updates, Vision
Last edited time: July 29, 2024 10:24 PM
Created time: July 29, 2024 10:24 PM

<aside>
💡 Notion Tip: A company mission provides direction and purpose, aligning actions and decisions towards a common goal. It also helps attract like-minded individuals who share the same values and vision for the company.

</aside>